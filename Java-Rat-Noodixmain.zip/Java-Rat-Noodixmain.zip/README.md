# Huzuni-Plus-Rat
- shitty https://github.com/TrvsF/discord-token-logger skid lol
- this was made to make tfb more secure bc some members are bipolar btw no one got perjudicated
- Disclaimer: Only for educational purposes im not responsable of the use of this 
